CREATE TRIGGER after_type_prestation_insert
AFTER INSERT ON tbgroupe_bareme
FOR EACH ROW
  BEGIN
    IF NEW.id >0 THEN
     SET @idgroupe= NEW.id; SET @iduser=NEW.user_create; 
    CALL `generatebareme`( @idgroupe, @iduser); 
       -- INSERT INTO tbbareme(date_create, date_delete, date_update, etat, id_type_prestation, montant, user_create, user_delete, user_update, verrou )
      --  SELECT(new.id,CONCAT('Hi ', NEW.name, ', please update your date of birth.')) FROM tbtype_prestation;
    END IF;
END;
