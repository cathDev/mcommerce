CREATE TRIGGER after_delete_groupe_bareme
AFTER UPDATE ON tbgroupe_bareme
FOR EACH ROW
  BEGIN
    IF NEW.etat = 0 THEN
     SET @idgroupe= NEW.id; SET @iduser=NEW.user_delete; 
    CALL `supprimebareme`( @idgroupe, @iduser); 
       -- INSERT INTO tbbareme(date_create, date_delete, date_update, etat, id_type_prestation, montant, user_create, user_delete, user_update, verrou )
      --  SELECT(new.id,CONCAT('Hi ', NEW.name, ', please update your date of birth.')) FROM tbtype_prestation;
    END IF;
END;
