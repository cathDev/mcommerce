CREATE TRIGGER createdetailbordereau
AFTER INSERT ON tbbordereau
FOR EACH ROW
  BEGIN
           	CALL createdetailsbordereau(NEW.datedebut, NEW.datefin, NEW.id_prestataire, NEW.id);
       END;
