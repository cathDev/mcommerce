CREATE PROCEDURE supprimebareme(IN idgroup INT, IN iduser INT)
  UPDATE tbbareme set etat = 0, user_delete = iduser, date_delete = CURRENT_DATE WHERE id_groupe_bareme = idgroup AND id_groupe_bareme NOT IN (SELECT * FROM tbgroupe_bareme_prestation WHERE id_groupe_bareme = idgroup);
