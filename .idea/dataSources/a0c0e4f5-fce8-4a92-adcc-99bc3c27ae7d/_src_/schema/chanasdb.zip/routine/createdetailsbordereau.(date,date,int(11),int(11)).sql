CREATE PROCEDURE createdetailsbordereau(IN datedebut DATE, IN datefin DATE, IN idPrestataire INT, IN idBordereau INT)
  INSERT INTO tbdetail_bordereau (id_bordereau, id_prestation)
SELECT DISTINCT idBordereau, tbprestation.id 
FROM tbprestation  
LEFT OUTER JOIN  tbdetail_prestation
ON tbprestation.id = tbdetail_prestation.id_prestation 
WHERE ( tbdetail_prestation.statut = 'F' AND tbdetail_prestation.id_prestataire_facture = idPrestataire AND tbdetail_prestation.date_update BETWEEN datedebut AND datefin)
OR ( tbprestation.statut = 'F' AND tbprestation.id_prestataire_facture = idPrestataire AND tbprestation.date_update BETWEEN datedebut AND datefin);
