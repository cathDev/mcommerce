CREATE PROCEDURE new_acte_prestation_by_assure_and_prestataire(IN idPrestataire INT, IN idAssure INT)
  SELECT tbprestataire.id as 'id_prestataire',
        tbactivites.id as 'id_activites',
        tbtype_prestation.id as 'id_type_prestation',
        tbcollege.id as 'id_college', 
        tbassure.id as 'id_assure'
FROM tbtype_prestation
LEFT OUTER JOIN tbactivites on tbactivites.id_type_prestation = tbtype_prestation.id
LEFT OUTER JOIN tbprestataire on tbprestataire.id = tbactivites.id_prestataire
LEFT OUTER JOIN tbbareme_assure on tbbareme_assure.id_type_prestation = tbtype_prestation.id
LEFT OUTER JOIN tbcollege on tbcollege.id = tbbareme_assure.id_college
LEFT OUTER JOIN tbassure on tbassure.id_college = tbcollege.id
WHERE tbprestataire.id = idPrestataire
AND tbassure.id = idAssure;
