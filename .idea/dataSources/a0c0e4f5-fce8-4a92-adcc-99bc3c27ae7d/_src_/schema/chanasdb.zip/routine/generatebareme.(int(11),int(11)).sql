CREATE PROCEDURE generatebareme(IN idgroup INT, IN iduser INT)
  INSERT INTO tbbareme(id_groupe_bareme,id_type_prestation, montant, etat, user_create) SELECT idgroup,id,0,1,iduser from tbtype_prestation where tbtype_prestation.etat = 1 AND id not in(SELECT id_type_prestation from tbbareme where id_groupe_bareme = idgroup AND tbbareme.etat = 1);
