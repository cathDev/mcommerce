CREATE PROCEDURE prestationbyprestataieandassure(IN idprestataire INT, IN idassure INT)
  SELECT  tbgroupe_bareme.id as 'id_groupe_bareme',
     tbbareme.id as 'id_bareme' ,
     tbtype_prestation.id as 'id_type_prestation',
     tbprestataire.id as 'id_prestataire',
     tbassure.id as 'id_assure',
     tbcollege.id as 'id_college'
     FROM tbassure
    left outer join tbcollege on tbcollege.id = tbassure.id_college
    left outer join tbgroupe_bareme on tbgroupe_bareme.id = tbcollege.id_groupe_bareme
    left outer join tbgroupe_bareme_prestataire on tbgroupe_bareme_prestataire.id_groupe_bareme = tbgroupe_bareme.id
    left outer join tbprestataire on tbprestataire.id = tbgroupe_bareme_prestataire.id_prestataire
    left outer join tbbareme on tbbareme.id_groupe_bareme = tbgroupe_bareme.id 
    left outer join tbtype_prestation on tbtype_prestation.id = tbbareme.id_type_prestation
    WHERE tbprestataire.id = idprestataire
    AND tbassure.id = idassure;
